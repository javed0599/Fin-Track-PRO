
import { GoogleGenAI } from "@google/genai";
import { Transaction } from "../types";

export const getFinancialAdvice = async (transactions: Transaction[]): Promise<string> => {
  if (transactions.length === 0) return "Add some transactions to get AI financial advice!";

  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
    const summary = transactions.map(t => `${t.date}: ${t.type} ${t.amount} in ${t.category} (${t.note})`).join('\n');
    
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Analyze the following financial transactions and provide 3 short, actionable tips to save money or manage budget better. Be concise and professional.\n\n${summary}`,
    });

    return response.text || "Unable to generate advice at this time.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Connect your financial history to get smart tips.";
  }
};
