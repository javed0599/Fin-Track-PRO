
import React from 'react';

// These serve as suggestions and icon mappings
export const DEFAULT_CATEGORIES = {
  income: ['Salary', 'Freelance', 'Investment', 'Gift', 'Refund', 'Other'],
  expense: ['Food', 'Transport', 'Rent', 'Shopping', 'Entertainment', 'Health', 'Bills', 'Travel', 'Other']
};

export const ICONS: Record<string, string> = {
  Salary: '💰',
  Freelance: '💻',
  Investment: '📈',
  Gift: '🎁',
  Refund: '🔄',
  Food: '🍔',
  Transport: '🚗',
  Rent: '🏠',
  Shopping: '🛍️',
  Entertainment: '🎮',
  Health: '🏥',
  Bills: '📄',
  Travel: '✈️',
  Other: '✨',
  Education: '📚',
  Groceries: '🛒',
  Gym: '🏋️',
  Insurance: '🛡️'
};
