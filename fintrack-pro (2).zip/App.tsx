
import React, { useState, useEffect, useMemo } from 'react';
import { 
  PieChart, Pie, Cell, ResponsiveContainer, Tooltip,
  BarChart, Bar, XAxis, YAxis, CartesianGrid 
} from 'recharts';
import { Transaction, FilterPeriod } from './types';
import { DEFAULT_CATEGORIES, ICONS } from './constants';
import { getFinancialAdvice } from './services/geminiService';

export default function App() {
  // User State
  const [userName, setUserName] = useState<string>(() => {
    return localStorage.getItem('fintrack_user_name') || '';
  });
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [tempUserName, setTempUserName] = useState(userName);

  // Transaction State
  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    const saved = localStorage.getItem('fintrack_data');
    return saved ? JSON.parse(saved) : [];
  });
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [filter, setFilter] = useState<FilterPeriod>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [aiAdvice, setAiAdvice] = useState<string>('');
  const [isAdviceLoading, setIsAdviceLoading] = useState(false);

  // Form State
  const [formData, setFormData] = useState<Omit<Transaction, 'id'>>({
    amount: 0,
    type: 'expense',
    category: 'Food',
    date: new Date().toISOString().split('T')[0],
    note: ''
  });

  // Persist User Data
  useEffect(() => {
    localStorage.setItem('fintrack_user_name', userName);
  }, [userName]);

  // Persist Transaction Data
  useEffect(() => {
    localStorage.setItem('fintrack_data', JSON.stringify(transactions));
  }, [transactions]);

  // Totals
  const totals = useMemo(() => {
    return transactions.reduce((acc, curr) => {
      const val = Number(curr.amount) || 0;
      if (curr.type === 'income') {
        acc.totalIncome += val;
        acc.totalBalance += val;
      } else {
        acc.totalExpense += val;
        acc.totalBalance -= val;
      }
      return acc;
    }, { totalBalance: 0, totalIncome: 0, totalExpense: 0 });
  }, [transactions]);

  // Filtering Logic
  const filteredTransactions = useMemo(() => {
    let list = [...transactions].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    
    if (searchTerm) {
      const lower = searchTerm.toLowerCase();
      list = list.filter(t => 
        t.note.toLowerCase().includes(lower) || 
        t.category.toLowerCase().includes(lower)
      );
    }

    const todayStr = new Date().toISOString().split('T')[0];
    if (filter === 'daily') {
      list = list.filter(t => t.date === todayStr);
    } else if (filter === 'weekly') {
      const cutoff = new Date();
      cutoff.setDate(cutoff.getDate() - 7);
      list = list.filter(t => new Date(t.date) >= cutoff);
    } else if (filter === 'monthly') {
      const cutoff = new Date();
      cutoff.setMonth(cutoff.getMonth() - 1);
      list = list.filter(t => new Date(t.date) >= cutoff);
    }

    return list;
  }, [transactions, filter, searchTerm]);

  // Chart Data: Category Breakdown
  const categoryData = useMemo(() => {
    const map: Record<string, number> = {};
    filteredTransactions.filter(t => t.type === 'expense').forEach(t => {
      map[t.category] = (map[t.category] || 0) + Number(t.amount);
    });
    return Object.entries(map).map(([name, value]) => ({ name, value }));
  }, [filteredTransactions]);

  // Chart Data: Last 7 Days Trends
  const dailyTrendData = useMemo(() => {
    const days = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const dateStr = d.toISOString().split('T')[0];
      days.push({ 
        date: dateStr, 
        display: d.toLocaleDateString('en-US', { weekday: 'short' }),
        income: 0, 
        expense: 0 
      });
    }

    transactions.forEach(t => {
      const day = days.find(d => d.date === t.date);
      if (day) {
        if (t.type === 'income') day.income += Number(t.amount);
        else day.expense += Number(t.amount);
      }
    });

    return days;
  }, [transactions]);

  // Handlers
  const handleAddOrEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.amount <= 0) return alert('Enter a valid amount');
    if (!formData.category.trim()) return alert('Category is required');

    const cleanData = { ...formData, category: formData.category.trim() };

    if (editingId) {
      setTransactions(prev => prev.map(t => t.id === editingId ? { ...cleanData, id: editingId } : t));
    } else {
      const newTransaction: Transaction = {
        ...cleanData,
        id: crypto.randomUUID()
      };
      setTransactions(prev => [newTransaction, ...prev]);
    }
    closeModal();
  };

  const handleDelete = (id: string) => {
    if (window.confirm('Are you sure you want to delete this transaction?')) {
      setTransactions(prev => prev.filter(t => t.id !== id));
    }
  };

  const openModal = (transaction?: Transaction) => {
    if (transaction) {
      setEditingId(transaction.id);
      setFormData({
        amount: transaction.amount,
        type: transaction.type,
        category: transaction.category,
        date: transaction.date,
        note: transaction.note
      });
    } else {
      setEditingId(null);
      setFormData({
        amount: 0,
        type: 'expense',
        category: DEFAULT_CATEGORIES.expense[0],
        date: new Date().toISOString().split('T')[0],
        note: ''
      });
    }
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setEditingId(null);
  };

  const saveProfile = () => {
    setUserName(tempUserName.trim());
    setIsProfileModalOpen(false);
  };

  const fetchAIAdvice = async () => {
    setIsAdviceLoading(true);
    const advice = await getFinancialAdvice(transactions);
    setAiAdvice(advice);
    setIsAdviceLoading(false);
  };

  const getCategoryIcon = (category: string) => {
    const found = Object.keys(ICONS).find(k => k.toLowerCase() === category.toLowerCase());
    return found ? ICONS[found] : '✨';
  };

  return (
    <div className="min-h-screen pb-24 max-w-md mx-auto relative px-4 pt-8">
      {/* Header */}
      <header className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-2xl font-bold bg-gradient-to-r from-emerald-400 to-cyan-400 bg-clip-text text-transparent">FinTrack Pro</h1>
          <p className="text-slate-400 text-sm">Welcome, {userName || 'Smart Saver'}</p>
        </div>
        <button 
          onClick={() => { setTempUserName(userName); setIsProfileModalOpen(true); }}
          className="w-10 h-10 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-xl hover:bg-slate-700 transition-colors shadow-lg active:scale-95 overflow-hidden"
        >
          {userName ? userName.charAt(0).toUpperCase() : '👤'}
        </button>
      </header>

      {/* Summary Cards */}
      <section className="glass rounded-3xl p-6 mb-6 relative overflow-hidden shadow-2xl">
        <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/10 blur-3xl -mr-16 -mt-16"></div>
        <p className="text-slate-400 text-sm mb-1">Total Balance</p>
        <h2 className="text-4xl font-bold mb-6 text-slate-50">৳{totals.totalBalance.toLocaleString()}</h2>
        
        <div className="grid grid-cols-2 gap-4">
          <div className="glass-dark rounded-2xl p-4 border-l-4 border-emerald-500">
            <p className="text-slate-400 text-[10px] mb-1 uppercase tracking-widest font-bold">Income</p>
            <p className="text-emerald-400 font-bold text-lg">৳{totals.totalIncome.toLocaleString()}</p>
          </div>
          <div className="glass-dark rounded-2xl p-4 border-l-4 border-rose-500">
            <p className="text-slate-400 text-[10px] mb-1 uppercase tracking-widest font-bold">Expenses</p>
            <p className="text-rose-400 font-bold text-lg">৳{totals.totalExpense.toLocaleString()}</p>
          </div>
        </div>
      </section>

      {/* AI Advice Section */}
      <section className="mb-6">
        <div className="glass rounded-2xl p-4 relative border border-purple-500/30">
          <div className="flex justify-between items-center mb-3">
            <div className="flex items-center gap-2">
              <span className="text-purple-400">✨</span>
              <h3 className="font-semibold text-sm">AI Financial Insight</h3>
            </div>
            <button 
              onClick={fetchAIAdvice}
              disabled={isAdviceLoading}
              className="text-[10px] uppercase tracking-wider bg-purple-500/20 text-purple-300 px-2 py-1 rounded-md hover:bg-purple-500/40 transition-colors disabled:opacity-50"
            >
              {isAdviceLoading ? 'Thinking...' : 'Analyze'}
            </button>
          </div>
          <p className="text-xs text-slate-300 italic leading-relaxed">
            {aiAdvice || "Click analyze to get spending tips tailored to your history."}
          </p>
        </div>
      </section>

      {/* Charts Section */}
      <section className="mb-8 overflow-hidden">
        <div className="flex justify-between items-end mb-4">
          <h3 className="font-bold">Analytics</h3>
          <div className="flex gap-2">
            {(['all', 'weekly', 'monthly'] as FilterPeriod[]).map((f) => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={`text-[10px] px-2 py-1 rounded-full border transition-all ${filter === f ? 'bg-slate-100 text-slate-900 border-slate-100 font-bold' : 'border-slate-700 text-slate-400'}`}
              >
                {f.charAt(0).toUpperCase() + f.slice(1)}
              </button>
            ))}
          </div>
        </div>
        
        <div className="space-y-4">
          {/* Daily Trends Bar Chart */}
          <div className="h-48 glass rounded-3xl p-4">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={dailyTrendData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                <XAxis dataKey="display" stroke="#64748b" fontSize={10} axisLine={false} tickLine={false} />
                <YAxis hide />
                <Tooltip 
                  cursor={{fill: 'rgba(255,255,255,0.05)'}}
                  contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '12px', fontSize: '10px' }}
                />
                <Bar dataKey="expense" fill="#f43f5e" radius={[4, 4, 0, 0]} barSize={20} />
                <Bar dataKey="income" fill="#10b981" radius={[4, 4, 0, 0]} barSize={20} />
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Category Pie Chart */}
          <div className="h-48 glass rounded-3xl p-4 flex flex-col items-center justify-center">
             {categoryData.length > 0 ? (
               <ResponsiveContainer width="100%" height="100%">
                 <PieChart>
                    <Pie
                      data={categoryData}
                      cx="50%"
                      cy="50%"
                      innerRadius={45}
                      outerRadius={65}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {categoryData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={['#10b981', '#ef4444', '#3b82f6', '#f59e0b', '#8b5cf6'][index % 5]} />
                      ))}
                    </Pie>
                    <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '12px', fontSize: '12px' }} />
                  </PieChart>
               </ResponsiveContainer>
             ) : (
               <div className="text-slate-500 text-xs text-center">
                 <p>No expense data for this period</p>
                 <p className="mt-1 opacity-50">Add expenses to see breakdown</p>
               </div>
             )}
          </div>
        </div>
      </section>

      {/* Transactions List */}
      <section>
        <div className="flex justify-between items-center mb-4">
          <h3 className="font-bold">Recent Activities</h3>
          <div className="relative">
             <input 
              type="text" 
              placeholder="Search..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="bg-slate-800/50 border border-slate-700 rounded-full px-4 py-1 text-xs focus:outline-none focus:border-emerald-500 w-32"
             />
          </div>
        </div>

        <div className="space-y-3">
          {filteredTransactions.length === 0 ? (
            <div className="text-center py-12 glass rounded-3xl opacity-50 border-dashed border-slate-800">
              <p className="text-sm">No transactions matched your filters</p>
            </div>
          ) : (
            filteredTransactions.map(t => (
              <div 
                key={t.id} 
                onClick={() => openModal(t)}
                className="glass-dark hover:glass rounded-2xl p-4 flex items-center gap-4 cursor-pointer transition-all group active:scale-[0.98]"
              >
                <div className="w-12 h-12 rounded-xl bg-slate-800 flex items-center justify-center text-xl shadow-inner group-hover:bg-slate-700 transition-colors">
                  {getCategoryIcon(t.category)}
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="font-medium text-sm truncate">{t.category}</h4>
                  <p className="text-[10px] text-slate-500 truncate">{t.note || 'No description'} • {t.date}</p>
                </div>
                <div className="text-right">
                  <p className={`font-bold text-sm ${t.type === 'income' ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {t.type === 'income' ? '+' : '-'}৳{Number(t.amount).toLocaleString()}
                  </p>
                  <button 
                    onClick={(e) => { e.stopPropagation(); handleDelete(t.id); }}
                    className="text-[10px] text-slate-600 hover:text-rose-500 opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    Delete
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </section>

      {/* Floating Action Button */}
      <button 
        onClick={() => openModal()}
        className="fixed bottom-8 left-1/2 -translate-x-1/2 w-16 h-16 bg-gradient-to-tr from-emerald-600 to-emerald-400 rounded-full shadow-2xl shadow-emerald-500/40 flex items-center justify-center text-3xl font-light hover:scale-110 active:scale-90 transition-all z-40"
      >
        <span className="mb-1 text-white">+</span>
      </button>

      {/* Profile Modal */}
      {isProfileModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm px-4">
          <div className="bg-slate-900 w-full max-w-sm rounded-[32px] p-8 border border-slate-700 shadow-2xl animate-in zoom-in-95 duration-200">
            <h2 className="text-xl font-bold mb-2">Your Profile</h2>
            <p className="text-slate-500 text-sm mb-6">Customize your experience</p>
            <div className="space-y-4">
              <div>
                <label className="text-xs text-slate-500 block mb-2 px-1">Display Name</label>
                <input 
                  type="text"
                  value={tempUserName}
                  onChange={(e) => setTempUserName(e.target.value)}
                  placeholder="Enter your name"
                  className="w-full bg-slate-800 border border-slate-700 rounded-2xl py-3 px-4 text-sm focus:outline-none focus:border-emerald-500"
                  autoFocus
                />
              </div>
              <div className="flex gap-4 pt-4">
                <button 
                  onClick={() => setIsProfileModalOpen(false)}
                  className="flex-1 py-3 text-slate-400 font-bold text-sm"
                >
                  Cancel
                </button>
                <button 
                  onClick={saveProfile}
                  className="flex-1 py-3 bg-emerald-500 rounded-2xl font-bold text-sm shadow-lg shadow-emerald-500/20 active:scale-95 transition-all text-white"
                >
                  Save Changes
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Transaction Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-slate-900 w-full max-w-md rounded-t-[40px] p-8 animate-in slide-in-from-bottom duration-300 shadow-2xl overflow-y-auto max-h-[95vh] border-t border-slate-700">
            <div className="w-12 h-1.5 bg-slate-800 rounded-full mx-auto mb-6 cursor-pointer" onClick={closeModal}></div>
            <h2 className="text-2xl font-bold mb-6 text-center">{editingId ? 'Edit Entry' : 'New Transaction'}</h2>
            
            <form onSubmit={handleAddOrEdit} className="space-y-6">
              {/* Type Toggle */}
              <div className="flex p-1 bg-slate-800 rounded-2xl">
                <button 
                  type="button"
                  onClick={() => setFormData({ ...formData, type: 'income', category: DEFAULT_CATEGORIES.income[0] })}
                  className={`flex-1 py-3 rounded-xl text-sm font-bold transition-all ${formData.type === 'income' ? 'bg-emerald-500 text-white shadow-lg' : 'text-slate-400'}`}
                >
                  Income
                </button>
                <button 
                  type="button"
                  onClick={() => setFormData({ ...formData, type: 'expense', category: DEFAULT_CATEGORIES.expense[0] })}
                  className={`flex-1 py-3 rounded-xl text-sm font-bold transition-all ${formData.type === 'expense' ? 'bg-rose-500 text-white shadow-lg' : 'text-slate-400'}`}
                >
                  Expense
                </button>
              </div>

              {/* Amount Input */}
              <div className="text-center">
                <label className="text-[10px] text-slate-500 block mb-2 uppercase tracking-widest font-bold">How much?</label>
                <div className="relative inline-block">
                  <span className="absolute -left-8 top-1/2 -translate-y-1/2 text-slate-500 text-2xl">৳</span>
                  <input 
                    type="number"
                    value={formData.amount || ''}
                    onChange={(e) => setFormData({ ...formData, amount: parseFloat(e.target.value) || 0 })}
                    className="bg-transparent border-b-2 border-slate-800 py-4 px-2 text-4xl font-bold focus:outline-none focus:border-emerald-500 text-center w-48"
                    placeholder="0.00"
                    required
                  />
                </div>
              </div>

              {/* Manual Category Entry with Suggestions */}
              <div>
                <label className="text-xs text-slate-500 block mb-2 px-1">Category</label>
                <input 
                  type="text"
                  value={formData.category}
                  onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                  placeholder="Food, Salary, Gift..."
                  className="w-full bg-slate-800 border border-slate-700 rounded-2xl py-3 px-4 text-sm focus:outline-none focus:border-emerald-500 mb-3"
                  required
                />
                <div className="flex flex-wrap gap-2">
                  {(formData.type === 'income' ? DEFAULT_CATEGORIES.income : DEFAULT_CATEGORIES.expense).map(c => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => setFormData({ ...formData, category: c })}
                      className={`text-[10px] px-3 py-1.5 rounded-full border transition-all ${formData.category === c ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/50' : 'bg-slate-800/40 text-slate-400 border-slate-800'}`}
                    >
                      {getCategoryIcon(c)} {c}
                    </button>
                  ))}
                </div>
              </div>

              {/* Date */}
              <div>
                <label className="text-xs text-slate-500 block mb-2 px-1">Date</label>
                <input 
                  type="date"
                  value={formData.date}
                  onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                  className="w-full bg-slate-800 border border-slate-700 rounded-2xl py-3 px-4 text-sm focus:outline-none"
                />
              </div>

              {/* Note */}
              <div>
                <label className="text-xs text-slate-500 block mb-2 px-1">Note (Optional)</label>
                <input 
                  type="text"
                  value={formData.note}
                  onChange={(e) => setFormData({ ...formData, note: e.target.value })}
                  placeholder="Lunch with friends..."
                  className="w-full bg-slate-800 border border-slate-700 rounded-2xl py-3 px-4 text-sm focus:outline-none focus:border-emerald-500"
                />
              </div>

              {/* Actions */}
              <div className="flex gap-4 pt-2 pb-8">
                <button 
                  type="button" 
                  onClick={closeModal}
                  className="flex-1 py-4 text-slate-400 font-bold"
                >
                  Cancel
                </button>
                <button 
                  type="submit"
                  className="flex-[2] py-4 bg-emerald-500 rounded-[20px] font-bold shadow-lg shadow-emerald-500/20 active:scale-95 transition-all text-white"
                >
                  {editingId ? 'Update Entry' : 'Save Transaction'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
