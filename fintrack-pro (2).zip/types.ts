
export type TransactionType = 'income' | 'expense';

export interface Transaction {
  id: string;
  amount: number;
  type: TransactionType;
  category: string;
  date: string;
  note: string;
}

export type FilterPeriod = 'daily' | 'weekly' | 'monthly' | 'all';

export interface FinancialSummary {
  totalBalance: number;
  totalIncome: number;
  totalExpense: number;
}
